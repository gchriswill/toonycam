//
//  TCAuthViewController.swift
//  Toony Cam
//
//  Created by Christopher Gonzalez on 10/30/16.
//  Copyright © 2016 Parthenon Studios. All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase

class TCAuthViewController: UIViewController {
    
    /*
     // MARK: - IMPORTANT
     */
    /// IMPORTANT
    // TODO: Future refactor needed. extract each completion block for each Firebase call back
    // to a modulirized clousure like so. Pay attention to dependencies due to there are some
    // values needed that will not be available in the clousure's scope. This is a foundation
    // start point. Needs fix for "out of scope" dependencies.
    
    //    var clousure = { (user:FIRUser?, error1:Error?) -> Void in
    //
    //    }
    
    //    var clousure = { (user:FIRUser?, error1:Error?) -> Void in
    //
    //        if user != nil && error1 == nil{
    //            userObj["id"] = user!.uid
    //            self.userCreateAccountProfile(forUser: user!, withUserObject: userObj)
    //        }else{
    //
    //        }
    //        
    //    }

    var isDisplayingPanel = false
    var isAnimatingPanel = false
    
    @IBOutlet weak var optionsPanel: TCAuthOptionsPanel!
    @IBOutlet weak var credentialsPanel: TCAuthCredentialsPanel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        optionsPanel.delegate = self
        credentialsPanel.delegate = self
        
        optionsPanel.resetPanel()
        credentialsPanel.resetPanel()
        
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(willShowKeyboard(notification:)),
                                               name: NSNotification.Name.UIKeyboardWillShow,
                                               object: nil)
        
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(willHideKeyboard(notification:)),
                                               name: NSNotification.Name.UIKeyboardWillHide,
                                               object: nil)
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        NotificationCenter.default.removeObserver(self,
                                                  name: NSNotification.Name.UIKeyboardWillShow,
                                                  object: nil)
        
        NotificationCenter.default.removeObserver(self,
                                                  name: NSNotification.Name.UIKeyboardWillHide,
                                                  object: nil)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let touchedView = touches.first!.view!
        
        switch touchedView.tag {
        case 3:
            print("\n TCAuthViewController --> Create")
            optionsPanel.resetPanel()
            //let panelName:String = optionsPanel.title!.text!.replacingOccurrences(of: "Login", with: "Create")
            //optionsPanel.title.text = panelName
            optionsPanel.authState = "Create"
            credentialsPanel.authState = "Create"
            credentialsPanel.authenticateButton.setTitle("Create", for: .normal)
            credentialsPanel.usernameTextField.isHidden = false
            credentialsPanel.confirmTextField.isHidden = false
            
            optionsPanel.animatePanel(panelId: optionsPanel.tag, direction: .up)
            break
        case 5:
            print("\n TCAuthViewController --> Login")
            optionsPanel.resetPanel()
            //let panelName:String = optionsPanel.title!.text!.replacingOccurrences(of: "Create", with: "Login")
            //optionsPanel.title.text = panelName
            optionsPanel.authState = "Login"
            credentialsPanel.authState = "Login"
            credentialsPanel.authenticateButton.setTitle("Login", for: .normal)
            credentialsPanel.usernameTextField.isHidden = true
            credentialsPanel.confirmTextField.isHidden = true
            
            optionsPanel.animatePanel(panelId: optionsPanel.tag, direction: .up)
            break
            
        case 28:
			
			self.view.endEditing(true)
            credentialsPanel.authenticateButton.setTitle("", for: .normal)
            credentialsPanel.loader.startAnimating()
            
            if touchedView.isKind(of:TCAuthCredentialsButton.self) {
                
                print("\n touchedView is TCAuthCredentialsButton --> Authenticating")
                
                if credentialsPanel.authState == "Create" {
                    optionsPanel.authState = "Authenticating"
                    credentialsPanel.authState = "Authenticating"
                    credentialsPanel.title.text = "Authenticating..."
                    print("\n userCreateAccount() --> Authenticating")
                    userCreateAccount()
                }
                
                if credentialsPanel.authState == "Login" {
                    optionsPanel.authState = "Authenticating"
                    credentialsPanel.authState = "Authenticating"
                    credentialsPanel.title.text = "Authenticating..."
                    print("\n userLogin() --> Authenticating")
                    userLogin()
                }
            }
            
            break
            
        default:
            print("\n TCAuthViewController --> Touched View Tag: \(touchedView.tag)")
            //fatalError("THIS DEFAULT CASE MUST NEVER BE REACHED...")
            self.view.endEditing(true)
            break
        }
    }
    
    func userLogin() -> Void {
        
        var userObj = [
            "email":credentialsPanel.emailTextField.text!,
            "pwd":credentialsPanel.passwordTextField.text!
            ]
        
        FIRAuth.auth()?.signIn(withEmail: userObj["email"]!, password: userObj["pwd"]!) { (user, error) in
            
            if user != nil && error == nil {
                
                // TODO: Preload system's and user's data.
                
                // Veryfying that the user has successfuly logged in...
                if FIRAuth.auth()?.currentUser != nil {
                    
                    self.dismiss(animated: true) {
                        
                        print("\n APPLICATION STATE LOG \n" +
                            "At this point. User has successfully logged in to his account." +
                            "We are traveling now back to the Camera module to have user's favorites filters already " +
                            "loaded and diplaying on screen.")
                    }
                    
                }else{
                    
                    let alert = UIAlertController(title: "Error on getting user's data...",
                                                  message: "The system has encounter an error. Please report the bug...",
                                                  preferredStyle: .alert)
                    
                    self.present(alert, animated: true)
                    //fatalError("Error on userCreateAccountDatabase 1 for CAUSE: \(error3?.localizedDescription)")
                }
                
                
            }else{
                let alert = UIAlertController(title: "Error while loggin in...",
                                              message: error?.localizedDescription,
                                              preferredStyle: .alert)
                
                self.present(alert, animated: true)
            }
        }
    }
    
    func userCreateAccount() -> Void {
        
        var userObj = [
            "username":credentialsPanel.usernameTextField.text!,
            "email":credentialsPanel.emailTextField.text!,
            "pwd":credentialsPanel.passwordTextField.text!,
            "id":""
        ]
        
        self.credentialsPanel.title.text = "Creating account..."

        FIRAuth.auth()?.createUser(withEmail: userObj["email"]!, password: userObj["pwd"]!) { (user, error1) in
            
            if user != nil && error1 == nil {
                userObj["id"] = user!.uid
                self.userCreateAccountProfile(forUser: user!, withUserObject: userObj)
            }else{
                
                let alert = UIAlertController(title: "Error while creating account",
                                              message: error1?.localizedDescription,
                                              preferredStyle: .alert)
                
                self.present(alert, animated: true)
                
                //fatalError("Error on userCreateAccount for CAUSE: \(error1?.localizedDescription)")
            }
        }
    }
    
    func userCreateAccountProfile(forUser user: FIRUser, withUserObject userObj:[String:String]) -> Void {
        
        let changeRequest = user.profileChangeRequest()
        
        changeRequest.displayName = userObj["username"]!
        changeRequest.commitChanges { error2 in
            if error2 == nil {
                
                // Profile updated.
                self.credentialsPanel.title.text = "Creating profile..."
                self.userCreateAccountDatabase(forUserObject: userObj)
                
            } else {
                
                // An error happened.
                let alert = UIAlertController(title: "Error while updating user's profile",
                                              message: error2?.localizedDescription,
                                              preferredStyle: .alert)
                self.present(alert, animated: true)
                //fatalError("Error on userCreateAccountProfile for CAUSE: \(error2?.localizedDescription)")
                
            }
        }
    }
    
    
    func userCreateAccountDatabase(forUserObject userObj:[String:String]) -> Void {
        
        let userRef = FIRDatabase.database().reference().child("users").child(userObj["id"]!)
        
        userRef.setValue(userObj) { (error3, ref) in
            
            if error3 == nil {
                
                // Account and all it's componets fully created.
                self.credentialsPanel.title.text = "Account Created..."
                self.credentialsPanel.loader.stopAnimating()
                self.credentialsPanel.animatePanel(panelId: self.credentialsPanel.tag, direction: .down)
                
                if FIRAuth.auth()?.currentUser != nil {
                    
                    self.dismiss(animated: true) {
                        
                        print("\n APPLICATION STATE LOG \n" +
                            "At this point. User has successfully created his account." +
                            "We are traveling now back to the Camera module to give users their favorites filters alreay " +
                            "loaded and diplaying on screen.")
                        
                    }
                    
                }else{
                    
                    let alert = UIAlertController(title: "Error on getting user's data...",
                                                  message: "The system has encaouterd an error. Please report the bug...",
                                                  preferredStyle: .alert)
                    self.present(alert, animated: true)
                    //fatalError("Error on userCreateAccountDatabase 1 for CAUSE: \(error3?.localizedDescription)")
                }
                
            }else{
                
                // An error happened.
                let alert = UIAlertController(title: "Error while Setting things up...",
                                              message: error3?.localizedDescription,
                                              preferredStyle: .alert)
                self.present(alert, animated: true)
                //fatalError("Error on userCreateAccountDatabase 2 for CAUSE: \(error3?.localizedDescription)")
            }
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    */
     
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        optionsPanel.animatePanel(panelId: optionsPanel.tag, direction: .down)
        credentialsPanel.animatePanel(panelId: credentialsPanel.tag, direction: .down)
        
        optionsPanel.resetPanel()
        credentialsPanel.resetPanel()
        
    }
}

extension TCAuthViewController: TCAuthPanelDelegate {
    
    func willShowKeyboard(notification: NSNotification) {
        
        if let _ = (notification.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            self.credentialsPanel.delegate.willShowKeyboardForCredentials(authState: self.credentialsPanel.authState!)
            self.credentialsPanel.delegate.didStartAnimatingPanel(panelId: 20)
            if self.credentialsPanel.controlPanelMover.constant == 0 {
                
                UIView.animate(withDuration: 0.75,
                               delay: 0,
                               usingSpringWithDamping: 0.9,
                               initialSpringVelocity: 0.8,
                               options: UIViewAnimationOptions.curveEaseOut,
                               animations: {
                                
                                self.credentialsPanel.controlPanelMover.constant = -110
                                self.view.layoutIfNeeded()
                                
                }) { (check) in
                    
                    self.credentialsPanel.delegate.didFinishAnimatingPanel(panelId: 20)
                    
                }
            }
        }
    }
    
    func willHideKeyboard(notification: NSNotification) {
        
        if let _ = (notification.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            self.credentialsPanel.delegate.willHideKeyboardForCredentials(authState: self.credentialsPanel.authState!)
            self.credentialsPanel.delegate.didStartAnimatingPanel(panelId: 20)
            if self.credentialsPanel.controlPanelMover.constant != 0 {
                UIView.animate(withDuration: 0.75,
                               delay: 0,
                               usingSpringWithDamping: 0.9,
                               initialSpringVelocity: 0.8,
                               options: UIViewAnimationOptions.curveEaseOut,
                               animations: {
                                
                                self.credentialsPanel.controlPanelMover.constant = 0
                                self.view.layoutIfNeeded()
                                
                }) { (check) in
                    
                    self.credentialsPanel.delegate.didFinishAnimatingPanel(panelId: 20)
                    
                }
            }
        }
    }
    
    func travelingToPanel(panelId: Int) {
        
        switch panelId {
        case 10:
            
            print("\n TCAuthViewController --> Showing panel 10")
            credentialsPanel.animatePanel(panelId: 20, direction: .right)
            optionsPanel.animatePanel(panelId: 10, direction: .center)
            break
        case 20:
            
            print("\n TCAuthViewController --> Showing panel 20")
            optionsPanel.animatePanel(panelId: 10, direction: .left)
            credentialsPanel.animatePanel(panelId: 20, direction: .center)
            break
        default:
            break
        }
    }
    
    func willShowKeyboardForCredentials(authState: String) {
        print("\n TCAuthViewController --> willShowKeyboardForCredentials --> for state\(authState)")
    }
    
    func willHideKeyboardForCredentials(authState: String) {
        print("\n TCAuthViewController --> willHideKeyboardForCredentials --> for state\(authState)")
    }
    
    func didStartAnimatingPanel(panelId:Int) {
        print("\n TCAuthViewController --> Animations STARTED for panel with ID: \(panelId)")
    }

    func didFinishAnimatingPanel(panelId:Int) {
        print("\n TCAuthViewController --> Animations FINISHED for panel with ID: \(panelId)")
    }
}
