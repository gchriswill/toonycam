//
//  TCCameraViewController.swift
//  Toony Cam
//
//  Created by Christopher Gonzalez on 10/24/16.
//  Copyright © 2016 Parthenon Studios. All rights reserved.
//

//Firebase ROOT database location: https://toony-cam.firebaseio.com/

import UIKit
//import FirebaseDatabase
//import FirebaseAuth

import AVFoundation
import ImageIO

import AssetsLibrary

class TCCameraViewController: UIViewController {
	
	var library:ALAssetsLibrary =  ALAssetsLibrary()
	
    var ref: FIRDatabaseReference!
    var canTakeShot = false
    var canTravel = false
    var isUiEnabled = false
    var isFirstLaunch = true
    
    // MARK: Magic properties
    /// AVFoundation's APIs properties Area ------------->
    
    // The layer where the camera outputs is previewed
    var previewLayer: AVCaptureVideoPreviewLayer!
    
    // The layer of for one face filter
    var hostCALayer: CALayer!
    
    // The session queue
    var sessionQueue: DispatchQueue = DispatchQueue(label: "videoQueue", attributes: [])
    
    //  AV's session properties
    var session: AVCaptureSession!
    var sessionConnection: AVCaptureConnection! // TODO: This property might not be needed...
    
    // Session's outputs objects
    var metadataOutput: AVCaptureMetadataOutput!
    var stillImageOutput:AVCaptureStillImageOutput!
    
    // Session's camera hardware in objects
    var frontCamera: AVCaptureDevice?
    var backCamera: AVCaptureDevice?
    /// -------------^
    
    @IBOutlet weak var camControlPanel: TCCamControlPanel!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        // Firebase'a root database object's location...
        if let _ = FIRAuth.auth()?.currentUser {
            // User is signed in.
            ref = FIRDatabase.database().reference()
            
        } else {
            // No user is signed in.
            performSegue(withIdentifier: "FROM_CAM_TO_AUTH", sender: nil)
            
        }
        
        self.magicSetup()
        
        print("\n FROM VIEW CON \n")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func unwindToCam(segue: UIStoryboardSegue) {
        
    }
    
    @IBAction func unwindByLogginOut(segue: UIStoryboardSegue) {
        
    }
    
    @IBAction func userAccountButtonAction(_ sender: UIBarButtonItem) {
        
        if let _ = FIRAuth.auth()?.currentUser {
            
            performSegue(withIdentifier: "FROM_CAM_TO_ACC", sender: nil)
            
        }else{
            
            performSegue(withIdentifier: "FROM_CAM_TO_AUTH", sender: nil)
            
        }
        
    }
    
    @IBAction func flashToogle(_ sender: UIBarButtonItem) {
        
        print("Flash Button Pressed")
        switch(sender.tag){
        case 101:
            sender.tag = 102
            sender.image = UIImage(named: "ic_flash_on_white_36pt")
            setCameraFlash(AVCaptureFlashMode.on, forDevice: &frontCamera!)
            break
        case 102:
            sender.tag = 100
            sender.image = UIImage(named: "ic_flash_off_white_36pt")
            setCameraFlash(AVCaptureFlashMode.off, forDevice: &frontCamera!)
            break
        default:
            sender.tag = 101
            sender.image = UIImage(named: "ic_flash_auto_white_36pt")
            setCameraFlash(AVCaptureFlashMode.auto, forDevice: &frontCamera!)
            break
        }
    }
    
    @IBAction func cameraToggle(_ sender: UIBarButtonItem) {
        
        self.previewLayer.opacity = 0.0
        sethostCALayerHidden(true)
        
        switch(sender.tag){
        case 200:
            sender.tag = 201
            sender.image = UIImage(named: "ic_camera_front_white_36pt")
            switchToCamera(position: .back)
            break
        default:
            sender.tag = 200
            sender.image = UIImage(named: "ic_camera_rear_white_36pt")
            switchToCamera(position: .front)
            break
        }
    }
    
    @IBAction func helpAction(_ sender: UIBarButtonItem) {
        
        
        
    }
	
	@IBAction func saveButt(sender: AnyObject) {
		
		
	}

    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        
        if let previewLayerConnection = previewLayer.connection {
            
            switch UIDevice.current.orientation {
            
            case .landscapeRight, .landscapeLeft:
                
                previewLayer.frame.size = size
                previewLayer.frame.origin = CGPoint(x: self.view.frame.origin.x - 71, y: self.view.frame.origin.y)
                
                self.navigationItem.leftBarButtonItems?.first?.isEnabled = false
                self.navigationItem.leftBarButtonItems?.first?.tintColor = UIColor.clear
                
                self.navigationItem.leftBarButtonItems?.last?.isEnabled = false
                self.navigationItem.leftBarButtonItems?.last?.tintColor = UIColor.clear
                
                break
                
            default:
                previewLayer.frame.size = size
                previewLayer.frame.origin = CGPoint(x: self.view.frame.origin.x, y: self.view.frame.origin.y - 71)
                
                self.navigationItem.leftBarButtonItems?.first?.isEnabled = true
                self.navigationItem.leftBarButtonItems?.first?.tintColor = self.navigationItem.rightBarButtonItems?.first?.tintColor
                
                self.navigationItem.leftBarButtonItems?.last?.isEnabled = true
                self.navigationItem.leftBarButtonItems?.last?.tintColor = self.navigationItem.rightBarButtonItems?.first?.tintColor
                
                break
            }
            
            previewLayerConnection.videoOrientation = AVCaptureVideoOrientation(rawValue: UIDevice.current.orientation.rawValue)!
            
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation
    // before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension TCCameraViewController: TCCamControlPanelDelegate {
	
    func didStartAnimatingPanelForActions() {
        canTakeShot = false
        canTravel = false
        isUiEnabled = false
    }
    
    func didFinishAnimatingPanelForAction(action: Int) {
        canTakeShot = true
        canTravel = true
        isUiEnabled = true
    }
    
    public func performCamAction(action:Int) {
        
        switch action {
        case 1:
            //Perform Segue to photo Library
            print("TRAVELING TO PHOTOS")
            performSegue(withIdentifier: "FROM_CAM_TO_PHOTOS", sender: nil)
            break
        case 2:
            //Perfom take shot action
            //Perfom Segue to Preview Results
            print("TAKING SHOT EXECUTION")
			takeShot()
			
            break
        case 3:
            print("TRAVELING TO FILTERS")
            //Perform Segue to filter library
            performSegue(withIdentifier: "FROM_CAM_TO_FILTERS", sender: nil)
            break
        default:
            fatalError("THIS DEFAULT CASE MUST NEVER BE REACHED")
            break
        }
    }
	
	func takeShot(){
		
		if session.isRunning{
			
			sessionConnection = stillImageOutput.connection(withMediaType: AVMediaTypeVideo)
			sessionConnection.videoOrientation = AVCaptureVideoOrientation(rawValue: UIDevice.current.orientation.rawValue)!
			stillImageOutput.captureStillImageAsynchronously(from: sessionConnection) {(sample, err) in
				
				//let imagebuff = CMGetAttachment(sample,  kCGImagePropertyExifDictionary, nil) as! CFDictionaryRef
				let imageShot = NSData(data: AVCaptureStillImageOutput.jpegStillImageNSDataRepresentation(sample)) as Data
				
				let imageData = UIImageJPEGRepresentation(UIImage(data: imageShot)!, 0.6)
				let compressedJPGImage = UIImage(data: imageData!)
				
				UIImageWriteToSavedPhotosAlbum(compressedJPGImage!, nil, nil, nil)
				
				DispatchQueue.main.async(execute:{() -> Void in
					
					
					
				})
			}
		}else{
			print("⚠️ Could Not take picture due to the session is not running...")
		}

	}
	
}




