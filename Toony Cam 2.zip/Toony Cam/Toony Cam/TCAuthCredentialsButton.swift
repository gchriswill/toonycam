//
//  TCAuthCredentialsButton.swift
//  Toony Cam
//
//  Created by Christopher Gonzalez on 11/3/16.
//  Copyright © 2016 Parthenon Studios. All rights reserved.
//

import UIKit

class TCAuthCredentialsButton: TCAuthButton {
    
    

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
