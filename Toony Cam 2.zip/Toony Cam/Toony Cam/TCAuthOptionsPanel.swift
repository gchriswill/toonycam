//
//  TCAuthOptionsControl.swift
//  Toony Cam
//
//  Created by Christopher Gonzalez on 10/31/16.
//  Copyright © 2016 Parthenon Studios. All rights reserved.
//

import UIKit


class TCAuthOptionsPanel: TCAuthPanel {
    
    @IBAction func cancelAction(_ sender:UIButton){
       self.animatePanel(panelId: self.tag, direction: .down)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        switch touches.first!.view!.tag  {
        case 13:
            print("TCAuthOptionsPanel --> Facebook")
            break
        case 14:
            print("TCAuthOptionsPanel --> Google+")
            break
        case 15:
            print("TCAuthOptionsPanel --> Username")
            self.delegate.travelingToPanel(panelId: 20)
            break
        default:
            print("TCAuthOptionsPanel --> Default")
            break
        }
    }
}

