//
//  File.swift
//  Toony Cam
//
//  Created by Christopher Gonzalez on 11/7/16.
//  Copyright © 2016 Parthenon Studios. All rights reserved.
//

import UIKit
import AVFoundation
import ImageIO

extension TCCameraViewController: AVCaptureMetadataOutputObjectsDelegate, AVCaptureVideoDataOutputSampleBufferDelegate {
    
    func magicSetup() {
        
        session = AVCaptureSession()
        session.sessionPreset = AVCaptureSessionPresetPhoto
        
        let avaliableCameraDevices = AVCaptureDevice.devices(withMediaType: AVMediaTypeVideo) as! [AVCaptureDevice]
        
        for device in avaliableCameraDevices {
            
            switch device.position {
            case .front:
                frontCamera = device
                setCameraFlash(AVCaptureFlashMode.auto, forDevice: &frontCamera!)
                break
            case .back:
                backCamera = device
                setCameraFlash(AVCaptureFlashMode.auto, forDevice: &backCamera!)
                break
            default:
                fatalError("There is no camera on this device...")
                break
            }
            
        }
        
        do {
            
            let input = try AVCaptureDeviceInput(device: frontCamera)
            
            if session.canAddInput(input){
                session.addInput(input)
            }else{
                print("Error !!!!")
            }
            
        } catch {
            print("Error handling the camera Input: \(error)")
            return
        }
        
        metadataOutput = AVCaptureMetadataOutput()
        stillImageOutput = AVCaptureStillImageOutput()
        
        // Setting 2 media output object configurations
        //
        if session.canAddOutput(metadataOutput) && session.canAddOutput(stillImageOutput) {
            
            session.addOutput(metadataOutput)
            
            stillImageOutput.outputSettings = [AVVideoCodecKey : AVVideoCodecJPEG];
            
            session.addOutput(stillImageOutput)
            
            metadataOutput.setMetadataObjectsDelegate(self, queue: sessionQueue)
            metadataOutput.metadataObjectTypes = [AVMetadataObjectTypeFace]
            
        }else{
            fatalError("Can't add object metadata")
        }
        
        // Preparing the AV's camera feed's preview layer
        previewLayer = AVCaptureVideoPreviewLayer(session: session)
        previewLayer.frame = view.bounds
        previewLayer.zPosition = -100
        previewLayer.videoGravity = AVLayerVideoGravityResizeAspect
        previewLayer.connection.videoOrientation = AVCaptureVideoOrientation.portrait
        
        previewLayer.frame.origin = CGPoint(x: 0, y: -71)
        
        view.layer.addSublayer(previewLayer)
        
        // Preparing the filter's Host layer
        hostCALayer = CALayer()
        hostCALayer.zPosition = 1
        hostCALayer.frame = previewLayer.frame
        
        //  \\ hostCALayer.borderColor = UIColor.red.cgColor
        // \\  hostCALayer.borderWidth = 3.0
        //hostCALayer.contents = UIImage(named: "dog_filter_p2")?.cgImage
        hostCALayer.contentsGravity = kCAGravityResizeAspectFill
        
        previewLayer.addSublayer(hostCALayer)
        
        for i in 0...2 {
            
            let faceCALayer = CALayer()
            faceCALayer.zPosition = 2
            faceCALayer.isHidden = true
            faceCALayer.contents = UIImage(named: "filter_\(i)")?.cgImage
            faceCALayer.contentsGravity = kCAGravityResize
            self.hostCALayer.addSublayer(faceCALayer)
            
        }
        
//        UIView.animate(withDuration: 0.75,
//                       delay: 0,
//                       usingSpringWithDamping: 0.9,
//                       initialSpringVelocity: 0.8,
//                       options: UIViewAnimationOptions.curveEaseOut,
//                       animations: {
//                        
//                        self.sheetmoverConstraint.constant = 0
//                        self.view.layoutIfNeeded()
//                        self.previewLayer.opacity = 1.0
//                        
//        }) { (check) in
//            
//            self.shouldOpenDrawer = true
//            //self.drawerButton.isEnabled = true
//            self.flashButton.isEnabled = true
//            self.shotImageButton.isEnabled = true
//            
//        }
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        UIApplication.shared.isStatusBarHidden = true
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if !session.isRunning{
            
            session.startRunning()
            previewLayer.isHidden = false
            previewLayer.opacity = 1
            
        }
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if self.session.isRunning{
            
            self.previewLayer.isHidden = true
            self.previewLayer.opacity = 0.0
            self.session.stopRunning()
            
        }
        
        // Old code for Pokemii --> PokeCam
        // by @gchriswill
        
//        self.shouldOpenDrawer = false
//        //self.drawerButton.isEnabled = false
//        self.flashButton.isEnabled = false
//        self.shotImageButton.isEnabled = false
//        
//        UIView.animate(withDuration: 0.75,
//                       delay: 0,
//                       usingSpringWithDamping: 0.9,
//                       initialSpringVelocity: 0.8,
//                       options: UIViewAnimationOptions.curveEaseOut,
//                       animations: {
//                        self.sheetmoverConstraint.constant = -193
//                        self.view.layoutIfNeeded()
//        }) { (check) in
        
//            if self.session.isRunning{
//                self.session.stopRunning()
//                self.previewLayer.isHidden = true
//                self.previewLayer.opacity = 0.0
//            }
//        }
        
    }
    
    // Old code for Pokemii --> PokeCam
    // by @gchriswill
    //
//    @IBAction func drawerToggle(_ sender: AnyObject) {
//        print("Drawer Button Pressed")
//        
//        if shouldOpenDrawer {
//            shouldOpenDrawer = false
//            
//            if isDrawerOpen {
//                isDrawerOpen = false
//                flashButton.isEnabled = false
//                shotImageButton.isEnabled = false
//                //shopButton.isEnabled = false
//                //settingsButton.isEnabled = false
//                
//                // drawerButton.isEnabled = false
//                //                drawerButton.setImage(UIImage(named: "ic_menu_white_48pt"),
//                //                                      for: UIControlState.normal)
//                //                UIView.animate(withDuration: 0.4,
//                //                                           delay: 0,
//                //                                           options: UIViewAnimationOptions.curveEaseIn,
//                //                                           animations: {
//                //                                            //self.shopMoverConstraint.constant = 100
//                //                                            self.view.layoutIfNeeded()
//                //                    }, completion: nil)
//                //
//                //                UIView.animate(withDuration: 0.4,
//                //                                           delay: 0.2,
//                //                                           options: UIViewAnimationOptions.curveEaseIn,
//                //                                           animations: {
//                //                                            //self.settingsMoverConstraint.constant = 100
//                //                                            self.view.layoutIfNeeded()
//                //                    }, completion: {(check) in
//                //                        self.drawerButton.isEnabled = true
//                //                        self.flashButton.isEnabled = true
//                //                        self.shotImageButton.isEnabled = true
//                //                        self.shouldOpenDrawer = true
//                //                })
//                
//            }else{
//                isDrawerOpen = true
//                //shopButton.isEnabled = true
//                //settingsButton.isEnabled = true
//                flashButton.isEnabled = false
//                shotImageButton.isEnabled = false
//                //drawerButton.isEnabled = false
//                //                drawerButton.setImage(UIImage(named: "ic_arrow_back_white_48pt"),
//                //                                      for: UIControlState.normal)
//                UIView.animate(withDuration: 0.2,
//                               delay:0,
//                               usingSpringWithDamping: 0.8,
//                               initialSpringVelocity: 0.8,
//                               options: UIViewAnimationOptions.curveEaseOut,
//                               animations: {
//                                //self.shopMoverConstraint.constant = 0
//                                self.view.layoutIfNeeded()
//                }, completion: {(check) in
//                    
//                })
//                
//                UIView.animate(withDuration: 0.2,
//                               delay:0.1,
//                               usingSpringWithDamping: 0.8,
//                               initialSpringVelocity: 0.8,
//                               options: UIViewAnimationOptions.curveEaseOut,
//                               animations: {
//                                //self.settingsMoverConstraint.constant = 0
//                                self.view.layoutIfNeeded()
//                }, completion: {(check) in
//                    //self.drawerButton.isEnabled = true
//                    self.flashButton.isEnabled = true
//                    self.shotImageButton.isEnabled = true
//                    self.shouldOpenDrawer = true
//                })
//            }
//        }
//    }
    
//    @IBAction func takeShot(_ sender: AnyObject) {
//        //print("Take Shot Button Pressed")
//        if canTakeShot && !isDrawerOpen {
//            canTakeShot = false
//            let layer = CALayer()
//            layer.name = "shadowEffector"
//            layer.frame = CGRect(x: shotImageButton.center.x, y: shotImageButton.center.y, width: 0, height: 0)
//            layer.backgroundColor = UIColor.black.cgColor
//            layer.zPosition = -1
//            layer.opacity = 0.05
//            
//            let layerTouch = CABasicAnimation(keyPath: "bounds")
//            layerTouch.toValue = NSValue(cgRect: CGRect(x: 0, y: 0, width: 600, height: 600))
//            layerTouch.duration = 0.75
//            layerTouch.timingFunction = CAMediaTimingFunction.init(name: kCAMediaTimingFunctionEaseInEaseOut)
//            layerTouch.isRemovedOnCompletion = false
//            //layerTouch.delegate = self
//            
//            let layerRound = CABasicAnimation(keyPath: "cornerRadius")
//            layerRound.toValue = 300
//            layerRound.duration = 0.75
//            layerRound.timingFunction = CAMediaTimingFunction.init(name: kCAMediaTimingFunctionEaseInEaseOut)
//            layerRound.isRemovedOnCompletion = false
//            
//            shooterSheet.layer.addSublayer(layer)
//            
//            shotImageButton.layer.shadowOpacity = 0.4
//            shotImageButton.layer.shadowOffset = CGSize(width: 0, height: 3.0)
//            
//            let layerShadow1 = CABasicAnimation(keyPath: "shadowOpacity")
//            layerShadow1.toValue = 0.6
//            layerShadow1.duration = 0.4
//            layerShadow1.timingFunction = CAMediaTimingFunction.init(name: kCAMediaTimingFunctionEaseInEaseOut)
//            layerShadow1.isRemovedOnCompletion = false
//            
//            let layerShadow2 = CABasicAnimation(keyPath: "shadowRadius")
//            layerShadow2.toValue = 6
//            layerShadow2.duration = 0.4
//            layerShadow2.timingFunction = CAMediaTimingFunction.init(name: kCAMediaTimingFunctionEaseInEaseOut)
//            layerShadow2.isRemovedOnCompletion = false
//            
//            shotImageButton.layer.add(layerShadow1, forKey: "shadowOpacity")
//            shotImageButton.layer.add(layerShadow2, forKey: "shadowRadius")
//            
//            layer.add(layerTouch, forKey: "bounds")
//            layer.add(layerRound, forKey: "cornerRadius")
//        }
//    }
    
//    func animationDidStop(_ anim: CAAnimation, finished flag: Bool) {
//        print("Buttuon Animation stopped...")
//        canTakeShot = true
//        for lay in shooterSheet.layer.sublayers! {
//            
//            if lay.name == "shadowEffector" {
//                lay.removeAllAnimations()
//                lay.removeFromSuperlayer()
//                self.canTakeShot = true
//                
//                //self.performSegueWithIdentifier("pkcam_to_pkpreviewer", sender: nil)
//                
//                if session.isRunning{
//                    
//                    sessionConnection = stillImageOutput.connection(withMediaType: AVMediaTypeVideo)
//                    sessionConnection.videoOrientation = AVCaptureVideoOrientation.portrait
//                    stillImageOutput.captureStillImageAsynchronously(from: sessionConnection) {(sample, err) in
//                        
//                        //let imagebuff = CMGetAttachment(sample,  kCGImagePropertyExifDictionary, nil) as! CFDictionaryRef
//                        self.imageShot = NSData(data: AVCaptureStillImageOutput.jpegStillImageNSDataRepresentation(sample)) as Data
//                        
//                        DispatchQueue.main.async(execute:{() -> Void in
//                            self.performSegue(withIdentifier: "pkcam_to_pkpreviewer", sender: nil)
//                            self.canTakeShot = true
//                        })
//                    }
//                }else{ print("⚠️ Could Not take picture due to the session is not running...") }
//            }
//        }
//    }
    
    func setCameraFlash(_ flashMode:AVCaptureFlashMode, forDevice device: inout AVCaptureDevice) {
        
        if session.isRunning && device.hasFlash {
            
            if device.isFlashModeSupported(flashMode) {
                do {
                    try device.lockForConfiguration()
                    device.flashMode = flashMode
                    device.unlockForConfiguration()
                } catch {
                    print("Error setting the currentDevice: \(error)")
                }
            }
        }
    }
    
    func sethostCALayerHidden(_ hidden: Bool) {
        if (hostCALayer.isHidden != hidden){
            DispatchQueue.main.async(execute:{() -> Void in
                self.hostCALayer.isHidden = hidden
            })
        }
    }
    
    func switchToCamera(position: AVCaptureDevicePosition){
        
        let currentInput = session.inputs.first as! AVCaptureDeviceInput
        self.session.removeInput(currentInput)
        
        do {
            
            let device = (position == .front ? frontCamera : backCamera)
            let input = try AVCaptureDeviceInput(device: device)
            
            if session.canAddInput(input){
                session.addInput(input)
                
                self.previewLayer.opacity = 1.0
                sethostCALayerHidden(false)
                
            }else{
                print("Error !!!! Couldn't switch inputs by adding the new input")
            }
            
        } catch {
            print("Error switching camera Input: \(error)")
            return
        }
    }
    
    func findMaxFaceRect(_ faces : Array<CGRect>) -> CGRect {
        
        if faces.count == 1 { return faces.first! }
        
        var maxFace = CGRect.zero
        var maxFace_size = maxFace.size.width + maxFace.size.height
        
        for face in faces {
            
            let face_size = face.size.width + face.size.height
            
            if (face_size > maxFace_size) {
                maxFace = face
                maxFace_size = face_size
            }
        }
        
        return maxFace
    }
    
    func captureOutput(_ captureOutput: AVCaptureOutput!,
                       didOutputMetadataObjects metadataObjects: [Any]!,
                       from connection: AVCaptureConnection!) {
        
        var faces = [AVMetadataFaceObject]()
        
        for metadataObject in metadataObjects as! [AVMetadataObject] {
            if metadataObject.type == AVMetadataObjectTypeFace {
                faces += [metadataObject as! AVMetadataFaceObject]
            }else{
                print("NO FACE Object")
            }
        }
        
        for l in self.hostCALayer.sublayers!.enumerated() {
            if l.offset >= faces.count {
                DispatchQueue.main.async() {
                    l.element.isHidden = true
                }
            }
        }
        
        if faces.count <= 0 {
            sethostCALayerHidden(true)
        }else{
            sethostCALayerHidden(false)
        }

        for face in faces.enumerated() {
            
            if let faceLayer = self.hostCALayer.sublayers?[face.offset] {
                
                let faceBounds = self.previewLayer.transformedMetadataObject(for: face.element).bounds
                
                 DispatchQueue.main.async() {
                    
                    faceLayer.name = "\(face.element.faceID)"
                    faceLayer.frame = faceBounds
                    faceLayer.isHidden = false
                    //faceLayer.backgroundColor = UIColor.green.cgColor
                    //faceLayer.opacity = 0.5
                    
                    faceLayer.removeAllAnimations()
                    
                    let cSize = faceLayer.frame.size
                    let cO = faceLayer.frame.origin
                    
                    faceLayer.frame.size = CGSize( width: (cSize.width * 1.5), height: (cSize.height * 1.5) )
                    let cameraInput = self.session.inputs.first as! AVCaptureDeviceInput
                    
                    if cameraInput.device.position == .front {
                        
                        faceLayer.frame.origin = CGPoint(x: cO.x - (cSize.width * 0.25),y: cO.y + (cSize.height / 5) )
                        
                    }else{
                        
                        faceLayer.frame.origin = CGPoint(x: cO.x - (cSize.width * 0.25),y: cO.y + (cSize.height / 2.5) )
                        
                    }
                }
            }
            
        //TODO: Need fix for bug with rotation
        //self.faceLayer.transform = CATransform3DMakeRotation(CGFloat(rawFace.rollAngle * CGFloat(M_PI / 180) ), 0.0, 0.0, 0.0)
        }
    }
	
//	func captureOutput(_ captureOutput: AVCaptureOutput!,
//	                   didOutputSampleBuffer sampleBuffer: CMSampleBuffer!, from connection: AVCaptureConnection!) {
//
//
//		
//	}

	func magicRenderer(){
		
		var uiImage = UIImage()
		var imageData = Data()
		
		//
		var faceLayer = CALayer()
		
		// Core Image variables
		var ciImageCore:CIImage?
		var ciDetector:CIDetector?
		let ciContext = CIContext()
		
		var faces = [CIFaceFeature]()
		
		uiImage = UIImage(data: imageData)!
		ciImageCore = CIImage(data: imageData)
		
		ciDetector = CIDetector(ofType: CIDetectorTypeFace, context: ciContext, options:[CIDetectorAccuracy: CIDetectorAccuracyHigh])
		
		//var faceObj = objects.first! as! CIFaceFeature
		
		var exifOrientation: Int;
		
		switch (uiImage.imageOrientation) {
		case .up:
			exifOrientation = 1;
			break;
		case .down:
			exifOrientation = 3;
			break;
		case .left:
			exifOrientation = 8;
			break;
		case .right:
			exifOrientation = 6;
			break;
		case .upMirrored:
			exifOrientation = 2;
			break;
		case .downMirrored:
			exifOrientation = 4;
			break;
		case .leftMirrored:
			exifOrientation = 5;
			break;
		case .rightMirrored:
			exifOrientation = 7;
			break;
		}
		
		print(exifOrientation)
		
		let objects = ciDetector!.features(in: ciImageCore!, options: [CIDetectorImageOrientation : exifOrientation])
		
		for fo in objects {
			if let cff = fo as? CIFaceFeature {
				faces += [cff]
			}
		}
			
		var newMemeImage: UIImage = UIImage()
		
		
		//dispatch_async(dispatch_get_global_queue(QOS_CLASS_DEFAULT, 0)) {
		
		//            var transform:CGAffineTransform = CGAffineTransformMakeScale(1, 1);
		//            transform = CGAffineTransformTranslate(transform, 0, -self.uiImage.size.height);
		//
		//            let faceRect: CGRect = CGRectApplyAffineTransform(cff.bounds, transform);
		
		for faceObj in faces.enumerated(){
			
			let face = faceObj.element
			var index = faceObj.offset
			
			print(view.frame)
			print(face.bounds)
			print(uiImage.size)
			
			let layer = CALayer()
			layer.borderColor = UIColor.red.cgColor
			layer.borderWidth = 2
			layer.bounds = face.bounds
			layer.contents = UIImage(named: "filter_0")

			layer.bounds.origin = CGPoint(x: face.bounds.origin.y, y: face.bounds.origin.x)
			
			DispatchQueue.global().async {
				
				UIGraphicsBeginImageContext(uiImage.size)
				uiImage.draw(in: CGRect(x: 0, y: 0, width: uiImage.size.width, height: uiImage.size.height))
				
				let context = UIGraphicsGetCurrentContext()
				//CGContextTranslateCTM(context, self.uiImage.size.height, self.uiImage.size.width)
				
				layer.render(in: context!)
				
				newMemeImage = UIGraphicsGetImageFromCurrentImageContext()!
				
				UIGraphicsEndImageContext()
				
				DispatchQueue.main.async { () -> Void in
					
					//TODO: Do stuff with the resulting image
					
				}
			}
		}
	}
}


// TODO: Position layer's pieces

//            let faceRect1: CGRect = CGRectApplyAffineTransform(
//                CGRectMake(0,
//                    0,
//                    pickaEars.size.width * 1.2,
//                    pickaEars.size.height * 1.5), transform);
//
//            pickaEars.drawInRect(faceRect1)
//
//            leftEye.drawInRect(
//                CGRectMake(
//                    cff!.leftEyePosition.x - leftEye.size.width/1.2,
//                    cff!.leftEyePosition.y - leftEye.size.height/1.2,
//                    leftEye.size.width * 1.5,
//                    leftEye.size.height * 1.5))
//
//            rightEye.drawInRect(
//                CGRectMake(
//                    cff!.rightEyePosition.x - rightEye.size.width/1.2,
//                    cff!.rightEyePosition.y - rightEye.size.height/1.2,
//                    rightEye.size.width * 1.5,
//                    rightEye.size.height * 1.5))
//
//            let faceRect2: CGRect = CGRectApplyAffineTransform(
//                CGRectMake(
//                    cff!.mouthPosition.x + circleLeft.size.width * 1.5,
//                    cff!.mouthPosition.y,
//                    circleLeft.size.width,
//                    circleLeft.size.height * 2), transform);
//            circleLeft.drawInRect(faceRect2)
//
//            let faceRect3: CGRect = CGRectApplyAffineTransform(
//                CGRectMake(
//                    cff!.mouthPosition.x + circleRight.size.width * -2.1,
//                    cff!.mouthPosition.y,
//                    circleRight.size.width,
//                    circleRight.size.height * 2), transform);
//
//            circleRight.drawInRect(faceRect3)

